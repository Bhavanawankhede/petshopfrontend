import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useShoppingCart } from "../context/ShoppingCartContext";
import { formatCurrency } from "../utilities/formatCurrency";
import {
  Box,
  Button,
  Card,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import AddShoppingCartSharpIcon from "@mui/icons-material/AddShoppingCartSharp";

type StoreFavouriteItemProps = {
  itemId: number;
  itemName: string;
  itemPrice: number;
  itemImage: string;
  itemDescription: string;
};

export function StoreFavouriteItem({
  itemId,
  itemName,
  itemPrice,
  itemImage,
  itemDescription,
}: StoreFavouriteItemProps) {
  const userEmail = localStorage.getItem("userEmail");
  const navigate = useNavigate();

  const Style: any = {
    width: 300,
  };

  const {
    getItemQuantity,
    increaseCartQuantity,
    decreaseCartQuantity,
    removeFromCart,
  } = useShoppingCart();

  const quantity = getItemQuantity(itemId);

  const removeFavourite = (itemId: any) => {
    axios
      .delete(
        `http://localhost:8080/favouriteList/removeFavouriteItem/${itemId}/${userEmail}`
      )
      .then(() => {
        console.log("fav item deleted");
        navigate("/items");
      });
  };

  return (
    <Box className="mainContainer2">
      <Card>
        <CardMedia
          component="img"
          image={require("E:/PetShopBackend29Nov/PetShop/Images/" +
            itemImage)}
          style={Style}
        />
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            <div className="itemTitle">{itemName}</div>
            <div className="itemPrice">{formatCurrency(itemPrice)}</div>
            <div className="itemDescription">{itemDescription}</div>
          </Typography>
          <div className="buttonDiv">
            <div className="row">
              {quantity === 0 ? (
                <Button
                  className="row"
                  onClick={() => increaseCartQuantity(itemId)}
                  variant="contained"
                >
                  <AddShoppingCartSharpIcon
                    style={{ color: "white" }}
                  ></AddShoppingCartSharpIcon>
                </Button>
              ) : (
                <div
                  className="d-flex align-items-center flex-column"
                  style={{ gap: ".5rem" }}
                >
                  <div className="btn-add-delete" style={{ gap: ".5rem" }}>
                    <Button
                      onClick={() => decreaseCartQuantity(itemId)}
                      variant="text"
                      size="large"
                    >
                      <RemoveIcon />
                    </Button>
                    <div>
                      <span className="fs-3">{quantity}</span> in cart
                    </div>
                    <Button
                      onClick={() => increaseCartQuantity(itemId)}
                      variant="text"
                      size="large"
                    >
                      <AddIcon />
                    </Button>

                    <br />
                    <Button
                      onClick={() => removeFromCart(itemId)}
                      variant="contained"
                      size="medium"
                      color="error"
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              )}
            </div>
            <div>
              <Button
                onClick={() => removeFavourite(itemId)}
                variant="text"
                size="large"
              >
                Remove
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Box>
  );
}
